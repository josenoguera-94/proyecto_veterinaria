import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-mascota',
  templateUrl: './editar-mascota.component.html',
  styleUrls: ['./editar-mascota.component.css']
})
export class EditarMascotaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
